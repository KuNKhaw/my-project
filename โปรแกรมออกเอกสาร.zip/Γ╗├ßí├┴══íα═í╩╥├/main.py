import sys
import os
import datetime
import sqlite3 # สำหรับฐานข้อมูล
import re # สำหรับ Regular Expression
import traceback # สำหรับแสดงรายละเอียดข้อผิดพลาด
from PyQt5.QtWidgets import (
    QApplication, QWidget, QFormLayout, QLabel, QLineEdit, QTextEdit,
    QPushButton, QDateEdit, QFileDialog, QMessageBox, QScrollArea,
    QVBoxLayout, QHBoxLayout, QComboBox, QTableWidget,
    QTableWidgetItem, QAbstractItemView
)
from PyQt5.QtCore import Qt, QDate
from docxtpl import DocxTemplate, InlineImage # สำหรับจัดการไฟล์ Word
from docx.shared import Mm # InlineImage might still be used for other purposes, Mm too.

try:
    import docx2pdf
    DOCX2PDF_AVAILABLE = True
except ImportError:
    print("Warning: docx2pdf library not found. PDF conversion will be unavailable.")
    DOCX2PDF_AVAILABLE = False

# Import translations
from translations import get_translator, set_language, FORM_TYPE_INTERNAL_KEYS, DEFAULT_COMPANY_NAME as DEFAULT_COMPANY_NAME_KEY, get_current_language_code, LEAVE_TYPE_OPTION_KEYS, CHANGE_DATA_TYPE_OPTION_KEYS, EXPENSE_PAYMENT_METHOD_OPTION_KEYS, APPRAISAL_RATING_OPTION_KEYS # Added more imports

class SmartFormApp(QWidget):
    def __init__(self):
        super().__init__()
        self._ = get_translator() # Initialize translator for the instance
        self.setWindowTitle(self._("window_title"))
        self.setGeometry(100, 100, 850, 720)

        self.base_script_path = os.path.dirname(os.path.abspath(__file__)) # Path ของ Script ปัจจุบัน
        self.template_dir = os.path.join(self.base_script_path, "templates")
        self.output_dir = os.path.join(self.base_script_path, "outputs")
        self.db_path = os.path.join(self.base_script_path, "history.db")

        # Use internal keys for template mapping
        self.form_template_files = {
            key: f"{key}.docx" for key in FORM_TYPE_INTERNAL_KEYS
        }
        # Example: self.form_template_files["leave_form"] will be "leave_form.docx"


        self.reason_label_widget = None # Will be created in _create_form_layout
        self.notes_label_widget = None  # Will be created in _create_form_layout

        # Tooltips for specific input fields
        self.field_tooltips = {
            "accident_datetime": self._("tooltip_accident_datetime")
        }

        # Centralized database column names
        self.db_column_names_for_insert = [
            "name", "position", "form_type_internal_key", "created_at", "file_path", "reason", # Changed form_type to form_type_internal_key
            "leave_type_specific", "start_date_specific", "end_date_specific",
            "employee_id", "department", "company_name", "total_leave_days",
            "assigned_person", "contact_phone_leave", "effective_date_resign",
            "delivery_recipient_name", "delivery_recipient_department",
            "generic_attachment_1", "generic_attachment_2", "generic_attachment_3", "generic_notes",
            "training_course_name", "training_start_date", "training_end_date", "training_organizer", "training_cost",
            "change_data_type", "change_data_old_details", "change_data_new_details", "change_data_effective_date",
            "ot_date", "ot_start_time", "ot_end_time",
            "expense_total_amount", "expense_payment_method",
            "general_request_details",
            "warning_date_of_incident", "warning_agreed_actions",
            "exit_interview_last_work_date", "exit_interview_suggestions",
            "appraisal_overall_rating",
            "warning_previous_actions", "exit_interview_likes", "exit_interview_dislikes",
            "appraisal_period_start", "appraisal_period_end",
            "appraisal_strengths", "appraisal_areas_for_improvement",
            "other_cert_type_description",
            "travel_destination", "travel_purpose", "travel_start_date", "travel_end_date", "travel_advance_amount",
            "purchase_item_desc", "purchase_quantity", "purchase_supplier_suggestion",
            "accident_datetime", "accident_location", "accident_details", "accident_witnesses"
        ]
        self.db_all_columns = ["id"] + self.db_column_names_for_insert

        # Ensure the number of insertable columns matches the expected count (62)
        # This count is based on the number of fields defined in db_column_names_for_insert
        if len(self.db_column_names_for_insert) != 62:
            QMessageBox.critical(self, self._("db_column_mismatch_error_title", # Assuming you add this key
                                 self._("db_column_mismatch_error", expected_cols=62, actual_cols=len(self.db_column_names_for_insert))))
            sys.exit(1)


        # Configuration for field visibility
        self.all_specific_field_keys = [] # Will be populated in _create_form_fields
        self.form_visibility_rules = {
            # Example: Use internal keys from FORM_TYPE_INTERNAL_KEYS
            "leave_form": ["leave_type", "start_date", "end_date", "total_leave_days", "assigned_person", "contact_phone_leave"],
            "resign_form": ["effective_date_resign"],
            "delivery_form": ["delivery_recipient_name", "delivery_recipient_department"],
            "training_request_form": ["training_course_name", "training_start_date", "training_end_date", "training_organizer", "training_cost"],
            "emp_data_change_form": ["change_data_type", "change_data_old_details", "change_data_new_details", "change_data_effective_date"],
            "ot_request_form": ["ot_date", "ot_start_time", "ot_end_time"],
            "cert_employment_form": [], # No specific fields other than common ones + reason
            "expense_claim_form": [
                "expense_header_1", "expense_date_1", "expense_desc_1", "expense_amount_1",
                "expense_header_2", "expense_date_2", "expense_desc_2", "expense_amount_2",
                "expense_header_3", "expense_date_3", "expense_desc_3", "expense_amount_3",
                "expense_total_amount", "expense_payment_method", "expense_account_number"
            ],
            "general_request_form": ["general_request_details"],
            "warning_notice_form": ["warning_date_of_incident", "warning_previous_actions", "warning_agreed_actions"],
            "exit_interview_form": ["exit_interview_last_work_date", "exit_interview_likes", "exit_interview_dislikes", "exit_interview_suggestions"],
            "performance_appraisal_form": ["appraisal_period_start", "appraisal_period_end", "appraisal_strengths", "appraisal_areas_for_improvement", "appraisal_overall_rating"],
            "other_cert_request_form": ["other_cert_type_description"],
            "travel_request_form": ["travel_destination", "travel_purpose", "travel_start_date", "travel_end_date", "travel_advance_amount"],
            "purchase_request_form": ["purchase_item_desc", "purchase_quantity", "purchase_supplier_suggestion"],
            "accident_report_form": ["accident_datetime", "accident_location", "accident_details", "accident_witnesses"]
        }

        try:
            self.ensure_directories_exist()
            self.init_db()
            self.init_ui()
            self.load_history()
        except OSError as e:
            QMessageBox.critical(self, self._("error_folder_creation_title"),
                                 f"{self._('error_folder_creation_message_prefix', folder=self.output_dir)}\n{e}") # Add new translation key
            sys.exit(1)
        except Exception as e:
            QMessageBox.critical(self, self._("critical_startup_error_title"),
                                 f"{self._('critical_startup_error_message')}\n{e}\n\nTraceback:\n{traceback.format_exc()}") # Add new translation key
            sys.exit(1)

    def ensure_directories_exist(self):
        os.makedirs(self.template_dir, exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)

    def _setup_styles(self):
        self.setStyleSheet("""
            QWidget { /* พื้นหลังหลัก */
                background-color: #F0F0F0; /* เทาอ่อนมากๆ */
                font-family: 'Segoe UI', sans-serif;
                font-size: 14px;
                color: #333333; /* สีตัวอักษรทั่วไป - เทาเข้ม */
            }
            QLabel#mainHeaderLabel { /* หัวข้อหลักของโปรแกรม */
                font-size: 22px;
                font-weight: bold;
                color: #007ACC; /* สีน้ำเงินสดใส */
                padding-bottom: 10px; /* Add some spacing */
            }
            QFormLayout > QLabel { /* ป้ายกำกับของช่องกรอกข้อมูล */
                font-size: 14px;
                font-weight: normal;
                color: #555555; /* เทากลาง */
                padding-top: 3px; /* Align better with input fields */
            }
            QLabel#expenseHeaderLabel { /* สไตล์เฉพาะสำหรับหัวข้อรายการเบิก */
                font-style: italic;
                color: #007ACC; /* สีน้ำเงินสดใส */
                padding-top: 5px;
                padding-bottom: 2px;
                font-weight: bold;
            }
            QLineEdit, QComboBox, QDateEdit, QTextEdit { /* ช่องกรอกข้อมูล */
                background-color: #FFFFFF; /* ขาว */
                border: 1px solid #CCCCCC; /* ขอบเทาอ่อน */
                border-radius: 4px;
                padding: 6px 10px;
                font-size: 14px;
                color: #333333; /* เทาเข้มสำหรับตัวอักษรในช่องกรอก */
            }
            QTextEdit { 
                min-height: 60px; 
            }
            QPushButton { /* ปุ่ม */
                background-color: #007ACC; /* สีน้ำเงินสดใส */
                color: #FFFFFF; /* White text */
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover { /* ปุ่มเมื่อเมาส์ชี้ */
                background-color: #005C99; /* สีน้ำเงินเข้มขึ้น */
            }
            QTableWidget, QScrollArea { /* ตารางและพื้นที่เลื่อน */
                background-color: #FFFFFF; /* ขาว */
                border: 1px solid #DDDDDD; /* ขอบเทาอ่อนมาก */
                border-radius: 4px;
            }
            QHeaderView::section { /* หัวตาราง */
                background-color: #E0E0E0; /* เทาอ่อน */
                font-weight: bold;
                border: 1px solid #CCCCCC; /* ขอบเทาอ่อน */
                padding: 4px;
                color: #333333; /* เทาเข้ม */
            }
            /* ทำให้ QComboBox dropdown list มีธีมสว่างด้วย */
            QComboBox QAbstractItemView { 
                background-color: #FFFFFF; /* ขาว */
                color: #333333; /* เทาเข้ม */
                selection-background-color: #007ACC; /* สีน้ำเงินสดใสสำหรับการเลือก */
                selection-color: #FFFFFF;
                border: 1px solid #CCCCCC; /* ขอบเทาอ่อน */
            }
            /* Fallback สำหรับ QLabel ทั่วไป หากไม่ได้ถูกครอบคลุมโดย selector ที่เฉพาะเจาะจงกว่า */
            QLabel { 
                font-size: 18px;
                font-weight: bold;
                color: #444444; /* เทาเข้มปานกลางสำหรับ QLabel อื่นๆ */
            }
        """)
    
    def _create_form_fields(self):
        self.fields = {
            "name": QLineEdit(),
            "employee_id": QLineEdit(),
            "position": QLineEdit(),
            "department": QLineEdit(),
            "company_name": QLineEdit(self._(DEFAULT_COMPANY_NAME_KEY)), # Use translated default
            "leave_type": QComboBox(),
            "start_date": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "end_date": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "total_leave_days": QLineEdit(readOnly=True),
            "assigned_person": QLineEdit(),
            "contact_phone_leave": QLineEdit(),
            "effective_date_resign": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "delivery_recipient_name": QLineEdit(),
            "delivery_recipient_department": QLineEdit(),
            "training_course_name": QLineEdit(),
            "training_start_date": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "training_end_date": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "training_organizer": QLineEdit(),
            "training_cost": QLineEdit(),
            "change_data_type": QComboBox(),
            "change_data_old_details": QTextEdit(),
            "change_data_new_details": QTextEdit(),
            "change_data_effective_date": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "ot_date": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "ot_start_time": QLineEdit(),
            "ot_end_time": QLineEdit(),
            # "expense_header_1": QLabel("--- รายการเบิก 1 ---"), # Will be created with objectName
            "expense_date_1": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "expense_desc_1": QLineEdit(),
            "expense_amount_1": QLineEdit(),
            # "expense_header_2": QLabel("--- รายการเบิก 2 ---"), # Will be created with objectName
            "expense_date_2": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "expense_desc_2": QLineEdit(),
            "expense_amount_2": QLineEdit(),
            # "expense_header_3": QLabel("--- รายการเบิก 3 ---"), # Will be created with objectName
            "expense_date_3": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "expense_desc_3": QLineEdit(),
            "expense_amount_3": QLineEdit(),
            "expense_total_amount": QLineEdit(readOnly=True),
            "expense_payment_method": QComboBox(),
            "expense_account_number": QLineEdit(),
            "general_request_details": QTextEdit(),
            "warning_date_of_incident": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "warning_previous_actions": QTextEdit(),
            "warning_agreed_actions": QTextEdit(),
            "exit_interview_last_work_date": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "exit_interview_likes": QTextEdit(),
            "exit_interview_dislikes": QTextEdit(),
            "exit_interview_suggestions": QTextEdit(),
            "appraisal_period_start": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "appraisal_period_end": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "appraisal_strengths": QTextEdit(),
            "appraisal_areas_for_improvement": QTextEdit(),
            "appraisal_overall_rating": QComboBox(),
            "other_cert_type_description": QLineEdit(),
            "travel_destination": QLineEdit(),
            "travel_purpose": QTextEdit(),
            "travel_start_date": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "travel_end_date": QDateEdit(calendarPopup=True, date=QDate.currentDate(), displayFormat="dd/MM/yyyy"),
            "travel_advance_amount": QLineEdit(),
            "purchase_item_desc": QTextEdit(),
            "purchase_quantity": QLineEdit(),
            "purchase_supplier_suggestion": QLineEdit(),
            "accident_datetime": QLineEdit(),
            "accident_location": QLineEdit(),
            "accident_details": QTextEdit(),
            "accident_witnesses": QLineEdit(),
            # "generic_attachment_1": QLineEdit(), # Will be created with a button
            "generic_attachment_1": QLineEdit(),
            "generic_attachment_2": QLineEdit(),
            "generic_attachment_3": QLineEdit(),
            "generic_notes": QTextEdit(),
            "reason": QTextEdit(),
        }
        
        expense_h1 = QLabel(self._("expense_header_1_text"))
        expense_h1.setObjectName("expenseHeaderLabel")
        self.fields["expense_header_1"] = expense_h1
        expense_h2 = QLabel(self._("expense_header_2_text"))
        expense_h2.setObjectName("expenseHeaderLabel")
        self.fields["expense_header_2"] = expense_h2
        expense_h3 = QLabel(self._("expense_header_3_text"))
        expense_h3.setObjectName("expenseHeaderLabel")
        self.fields["expense_header_3"] = expense_h3

        # Populate ComboBoxes with translated items and internal keys
        def populate_combobox_with_keys(combo_box_key, option_keys_list):
            combo_box = self.fields.get(combo_box_key)
            if combo_box:
                combo_box.clear() # Clear any existing items
                for option_key in option_keys_list:
                    # Add translated display name and store the internal key as item data
                    combo_box.addItem(self._(option_key), option_key)

        populate_combobox_with_keys("leave_type", LEAVE_TYPE_OPTION_KEYS)
        populate_combobox_with_keys("change_data_type", CHANGE_DATA_TYPE_OPTION_KEYS)
        populate_combobox_with_keys("expense_payment_method", EXPENSE_PAYMENT_METHOD_OPTION_KEYS)
        populate_combobox_with_keys("appraisal_overall_rating", APPRAISAL_RATING_OPTION_KEYS)


        self.fields["start_date"].dateChanged.connect(self._calculate_leave_days)
        self.fields["end_date"].dateChanged.connect(self._calculate_leave_days)
        self.fields["expense_amount_1"].textChanged.connect(self._calculate_expense_total)
        self.fields["expense_amount_2"].textChanged.connect(self._calculate_expense_total)
        self.fields["expense_amount_3"].textChanged.connect(self._calculate_expense_total)

        # Apply tooltips
        for field_key, tooltip_text in self.field_tooltips.items():
            if field_key in self.fields:
                self.fields[field_key].setToolTip(tooltip_text)

        common_fields_to_exclude = {
            "name", "employee_id", "position", "department", "company_name",
            "generic_attachment_1", "generic_attachment_2", "generic_attachment_3",
            "generic_notes", "reason"
        }
        self.all_specific_field_keys = [
            key for key in self.fields.keys() if key not in common_fields_to_exclude
        ]

    def _create_form_layout(self):
        form_layout = QVBoxLayout()
        self.form_entries = QFormLayout()
        self.form_layout_structure = [] # To store (label_key, widget_key_or_widget) for retranslation

        # Helper to add rows with translated labels
        def add_translated_row(label_key, widget_key_or_widget):
            widget = self.fields[widget_key_or_widget] if isinstance(widget_key_or_widget, str) else widget_key_or_widget
            self.form_entries.addRow(self._(label_key), widget)
            self.form_layout_structure.append((label_key, widget_key_or_widget))

        # Define the structure of your form here
        # This list will be used to build the form and to retranslate labels
        self.form_structure_definition = [
            ("company_name_label", "company_name"), ("employee_name_label", "name"),
            ("employee_id_label", "employee_id"), ("position_label", "position"),
            ("department_label", "department"), ("leave_type_label", "leave_type"),
            ("start_date_label", "start_date"), ("end_date_label", "end_date"),
            ("total_leave_days_label", "total_leave_days"), ("assigned_person_label", "assigned_person"),
            ("contact_phone_leave_label", "contact_phone_leave"), ("effective_date_resign_label", "effective_date_resign"),
            ("delivery_recipient_name_label", "delivery_recipient_name"), ("delivery_recipient_department_label", "delivery_recipient_department"),
            ("training_course_name_label", "training_course_name"), ("training_start_date_label", "training_start_date"),
            ("training_end_date_label", "training_end_date"), ("training_organizer_label", "training_organizer"),
            ("training_cost_label", "training_cost"), ("change_data_type_label", "change_data_type"),
            ("change_data_old_details_label", "change_data_old_details"), ("change_data_new_details_label", "change_data_new_details"),
            ("change_data_effective_date_label", "change_data_effective_date"), ("ot_date_label", "ot_date"),
            ("ot_start_time_label", "ot_start_time"), ("ot_end_time_label", "ot_end_time"),
            # Expense headers are handled slightly differently as they are full-row widgets
            (None, "expense_header_1"), # No label key for full-row widget
            ("expense_date_1_label", "expense_date_1"), ("expense_desc_1_label", "expense_desc_1"),
            ("expense_amount_1_label", "expense_amount_1"),
            (None, "expense_header_2"),
            ("expense_date_2_label", "expense_date_2"), ("expense_desc_2_label", "expense_desc_2"),
            ("expense_amount_2_label", "expense_amount_2"),
            (None, "expense_header_3"),
            ("expense_date_3_label", "expense_date_3"), ("expense_desc_3_label", "expense_desc_3"),
            ("expense_amount_3_label", "expense_amount_3"),
            ("expense_total_amount_label", "expense_total_amount"), ("expense_payment_method_label", "expense_payment_method"),
            ("expense_account_number_label", "expense_account_number"), ("general_request_details_label", "general_request_details"),
            ("warning_date_of_incident_label", "warning_date_of_incident"), ("warning_previous_actions_label", "warning_previous_actions"),
            ("warning_agreed_actions_label", "warning_agreed_actions"), ("exit_interview_last_work_date_label", "exit_interview_last_work_date"),
            ("exit_interview_likes_label", "exit_interview_likes"), ("exit_interview_dislikes_label", "exit_interview_dislikes"),
            ("exit_interview_suggestions_label", "exit_interview_suggestions"), ("appraisal_period_start_label", "appraisal_period_start"),
            ("appraisal_period_end_label", "appraisal_period_end"), ("appraisal_strengths_label", "appraisal_strengths"),
            ("appraisal_areas_for_improvement_label", "appraisal_areas_for_improvement"), ("appraisal_overall_rating_label", "appraisal_overall_rating"),
            ("other_cert_type_description_label", "other_cert_type_description"), ("travel_destination_label", "travel_destination"),
            ("travel_purpose_label", "travel_purpose"), ("travel_start_date_label", "travel_start_date"),
            ("travel_end_date_label", "travel_end_date"), ("travel_advance_amount_label", "travel_advance_amount"),
            ("purchase_item_desc_label", "purchase_item_desc"), ("purchase_quantity_label", "purchase_quantity"),
            ("purchase_supplier_suggestion_label", "purchase_supplier_suggestion"), ("accident_datetime_label", "accident_datetime"),
            ("accident_location_label", "accident_location"), ("accident_details_label", "accident_details"),
            ("accident_witnesses_label", "accident_witnesses"),
        ]

        for label_key, widget_identifier in self.form_structure_definition:
            widget = self.fields.get(widget_identifier) if isinstance(widget_identifier, str) else widget_identifier
            if widget: # Ensure widget exists
                if label_key: # It's a standard row with a label and a widget
                    add_translated_row(label_key, widget_identifier)
                else: # It's a full-row widget (like expense_header_1)
                    self.form_entries.addRow(widget)
                    self.form_layout_structure.append((None, widget_identifier)) # Store for retranslation if needed (though headers might not need label retranslation)
            else:
                print(f"Warning: Widget for identifier '{widget_identifier}' not found in self.fields.")

        # Attachment 1 with Browse button
        attachment1_layout = QHBoxLayout()
        attachment1_layout.addWidget(self.fields["generic_attachment_1"])
        browse_btn1 = QPushButton(self._("browse_button"))
        browse_btn1.clicked.connect(lambda: self._browse_file(self.fields["generic_attachment_1"]))
        attachment1_layout.addWidget(browse_btn1)
        add_translated_row("attachment1_label", attachment1_layout)

        # Attachment 2 with Browse button
        attachment2_layout = QHBoxLayout()
        attachment2_layout.addWidget(self.fields["generic_attachment_2"])
        browse_btn2 = QPushButton(self._("browse_button"))
        browse_btn2.clicked.connect(lambda: self._browse_file(self.fields["generic_attachment_2"]))
        attachment2_layout.addWidget(browse_btn2)
        add_translated_row("attachment2_label", attachment2_layout)

        # Attachment 3 with Browse button
        attachment3_layout = QHBoxLayout()
        attachment3_layout.addWidget(self.fields["generic_attachment_3"])
        browse_btn3 = QPushButton(self._("browse_button"))
        browse_btn3.clicked.connect(lambda: self._browse_file(self.fields["generic_attachment_3"]))
        attachment3_layout.addWidget(browse_btn3)
        add_translated_row("attachment3_label", attachment3_layout)

        self.notes_label_widget = QLabel(self._("notes_default")) # Default, will be updated
        self.form_entries.addRow(self.notes_label_widget, self.fields["generic_notes"])
        self.form_layout_structure.append(("notes_default", "generic_notes")) # Special handling for notes label

        self.reason_label_widget = QLabel(self._("reason_default")) # Default, will be updated
        self.form_entries.addRow(self.reason_label_widget, self.fields["reason"])
        self.form_layout_structure.append(("reason_default", "reason")) # Special handling for reason label

        form_layout.addLayout(self.form_entries)
        return form_layout

    def _create_buttons_layout(self):
        buttons = QHBoxLayout()
        self.submit_btn = QPushButton(self._("submit_button"))
        self.submit_btn.setCursor(Qt.PointingHandCursor)
        self.submit_btn.setToolTip(self._("tooltip_submit_button"))
        self.submit_btn.clicked.connect(self.generate_form)
        self.clear_form_btn = QPushButton(self._("clear_button"))
        self.clear_form_btn.setCursor(Qt.PointingHandCursor)
        self.clear_form_btn.setToolTip(self._("tooltip_clear_button"))
        self.clear_form_btn.clicked.connect(self._clear_form_fields)
        self.open_output_folder_btn = QPushButton(self._("open_folder_button"))
        self.open_output_folder_btn.setCursor(Qt.PointingHandCursor)
        self.open_output_folder_btn.setToolTip(self._("tooltip_open_folder_button"))
        self.open_output_folder_btn.clicked.connect(self.open_output_folder)
        buttons.addWidget(self.clear_form_btn)
        buttons.addWidget(self.open_output_folder_btn)
        buttons.addWidget(self.submit_btn)
        return buttons

    def _create_history_table(self):
        self.table = QTableWidget()
        self.table.setColumnCount(10)
        self.table.setHorizontalHeaderLabels([
            self._("history_name"), self._("history_employee_id"), 
            self._("history_department"), self._("history_position"), 
            self._("history_form_type"), self._("history_reason_subject"), 
            self._("history_leave_type"), self._("history_start_date"), 
            self._("history_end_date"), self._("history_created_at")
        ])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.itemDoubleClicked.connect(self.open_history_file)
        self.table.setMouseTracking(True)
        self.table.viewport().setCursor(Qt.PointingHandCursor)
        return self.table

    def init_ui(self):
        try:
            self._setup_styles()
            layout = QVBoxLayout(self) # type: ignore
            header = QLabel(self._("main_header"))
            header.setObjectName("mainHeaderLabel") # For specific styling
            layout.addWidget(header)

            # Populate form_selector with translated names and internal keys as data
            self.form_selector = QComboBox()
            for internal_key in FORM_TYPE_INTERNAL_KEYS:
                display_name = self._(internal_key) # Translate form type name
                self.form_selector.addItem(display_name, internal_key) # Store internal_key
            self.form_selector.currentIndexChanged.connect(self.update_fields_visibility)

            self._create_form_fields()
            form_content_layout = self._create_form_layout()
            self.form_entries.insertRow(0, self._("select_form_type_label"), self.form_selector) # Use QFormLayout's insertRow
            buttons_layout = self._create_buttons_layout()
            form_content_layout.addLayout(buttons_layout)
            scroll_content_widget = QWidget()
            scroll_content_widget.setLayout(form_content_layout)
            scroll_area = QScrollArea()
            scroll_area.setWidgetResizable(True)
            scroll_area.setWidget(scroll_content_widget)
            layout.addWidget(scroll_area)
            self.table = self._create_history_table()
            layout.addWidget(self.table)
            self.delete_history_btn = QPushButton(self._("delete_history_button"))
            self.delete_history_btn.setCursor(Qt.PointingHandCursor)
            self.delete_history_btn.setToolTip(self._("tooltip_delete_history_button"))
            self.delete_history_btn.clicked.connect(self.delete_selected_history)
            history_buttons_layout = QHBoxLayout()
            history_buttons_layout.addStretch()
            history_buttons_layout.addWidget(self.delete_history_btn)
            layout.addLayout(history_buttons_layout)

            # Language Selector
            lang_layout = QHBoxLayout()
            self.lang_label = QLabel(self._("language_label")) # Store as instance attribute
            self.lang_selector = QComboBox()
            self.lang_selector.addItem("ไทย (Thai)", "th")
            self.lang_selector.addItem("English (อังกฤษ)", "en")
            
            current_lang = get_current_language_code()
            if current_lang == "th":
                self.lang_selector.setCurrentIndex(0)
            else: # Default to English if not 'th' or if 'en'
                self.lang_selector.setCurrentIndex(1)

            self.lang_selector.currentTextChanged.connect(self._change_language)
            lang_layout.addStretch()
            lang_layout.addWidget(self.lang_label)
            lang_layout.addWidget(self.lang_selector)
            layout.addLayout(lang_layout)

            self.update_fields_visibility()
        except Exception as e:
            QMessageBox.critical(self, self._("error_ui_creation_title"),
                                 f"{self._('error_ui_creation_message')}\n{e}\n\nTraceback:\n{traceback.format_exc()}") # Add new translation key
            sys.exit(1)

    def _calculate_leave_days(self):
        # Ensure form_selector and total_leave_days field exist
        if not hasattr(self, 'form_selector') or "total_leave_days" not in self.fields:
            return
        current_form_internal_key = self.form_selector.currentData()
        if not current_form_internal_key: # Not selected yet or invalid
            self.fields["total_leave_days"].setText("")
            return
        if current_form_internal_key == "leave_form":
            start_date = self.fields["start_date"].date()
            end_date = self.fields["end_date"].date()
            if start_date <= end_date:
                days = start_date.daysTo(end_date) + 1
                self.fields["total_leave_days"].setText(str(days)) # แสดงเฉพาะตัวเลข
            else:
                self.fields["total_leave_days"].setText(self._("invalid_date_range"))

    def _calculate_expense_total(self):
        # Ensure form_selector and expense_total_amount field exist
        if not hasattr(self, 'form_selector') or "expense_total_amount" not in self.fields:
            return
        current_form_internal_key = self.form_selector.currentData()
        if not current_form_internal_key: # Not selected yet or invalid
            self.fields["expense_total_amount"].setText("")
            return

        if current_form_internal_key == "expense_claim_form":
            total = 0
            for i in range(1, 4):
                amount_str = self.fields[f"expense_amount_{i}"].text().strip()
                if amount_str:
                    try:
                        amount_float = float(amount_str)
                        total += amount_float
                    except ValueError:
                        pass
            self.fields["expense_total_amount"].setText(f"{total:.2f}")

    def _clear_form_fields(self):
        for field_name, widget in self.fields.items():
            if field_name == "company_name":
                widget.setText(self._(DEFAULT_COMPANY_NAME_KEY)) # Use translated default company name key
            elif isinstance(widget, QLineEdit) or isinstance(widget, QTextEdit):
                widget.clear()
            elif isinstance(widget, QComboBox):
                widget.setCurrentIndex(0)
            elif isinstance(widget, QDateEdit): # Correctly handle QDateEdit
                widget.setDate(QDate.currentDate())
        self._calculate_leave_days()
        self._calculate_expense_total() # เพิ่มบรรทัดนี้
        QMessageBox.information(self, self._("clear_form_success_title"), self._("clear_form_success_message"))

    def _browse_file(self, line_edit_widget):
        file_path, _ = QFileDialog.getOpenFileName(self, "เลือกไฟล์เอกสารแนบ", "", "All Files (*);;PDF Files (*.pdf);;Word Documents (*.docx *.doc)")
        if file_path:
            line_edit_widget.setText(file_path)
            print(f"📎 Selected file: {file_path} for {line_edit_widget}")


    def open_output_folder(self):
        try:
            if sys.platform == "win32":
                os.startfile(self.output_dir)
            print(f"📂 Opened output folder: {self.output_dir}")
        except Exception as e:
            QMessageBox.warning(self, self._("open_folder_error_title"), f"ไม่สามารถเปิดโฟลเดอร์ {self.output_dir} โดยอัตโนมัติได้\nรายละเอียด: {e}")

    def update_fields_visibility(self):
        current_form_internal_key = self.form_selector.currentData()
        if not hasattr(self, 'form_entries'): # UI not fully initialized
            return

        if not current_form_internal_key: # If no form type is selected or data is None
            # Hide all fields that are considered "specific" to a form type
            for field_key in self.all_specific_field_keys:
                widget = self.fields.get(field_key)
                if widget:
                    widget.setVisible(False)
                    label_in_layout = self.form_entries.labelForField(widget)
                    if label_in_layout:
                        label_in_layout.setVisible(False)
            
            # Explicitly hide reason, notes, and attachments as they are common but form-dependent
            if self.reason_label_widget: self.reason_label_widget.setVisible(False)
            if "reason" in self.fields: self.fields["reason"].setVisible(False)
            
            if self.notes_label_widget: self.notes_label_widget.setVisible(False)
            if "generic_notes" in self.fields: self.fields["generic_notes"].setVisible(False)
            
            for i in range(1, 4):
                attach_field_key = f"generic_attachment_{i}"
                attach_label_key = f"attachment{i}_label" # Key used in form_layout_structure
                
                # Find the QHBoxLayout for the attachment from form_layout_structure
                for lbl_key_struct, widget_id_struct in self.form_layout_structure:
                    if lbl_key_struct == attach_label_key:
                        if isinstance(widget_id_struct, QHBoxLayout):
                            widget_id_struct.setVisible(False) # Hide the QHBoxLayout (contains QLineEdit & QPushButton)
                            label_for_layout = self.form_entries.labelForField(widget_id_struct)
                            if label_for_layout:
                                label_for_layout.setVisible(False) # Hide its label
                        break
            # Ensure common fields like name, company_name are visible
            for common_key in ["company_name", "name", "employee_id", "position", "department"]:
                if common_key in self.fields:
                    self.fields[common_key].setVisible(True)
                    label = self.form_entries.labelForField(self.fields[common_key])
                    if label: label.setVisible(True)
                return

        visible_keys_for_current_form = self.form_visibility_rules.get(current_form_internal_key, [])
        for field_key in self.all_specific_field_keys:
            widget = self.fields.get(field_key)
            if widget:
                widget.setVisible(False)
                label_in_layout = self.form_entries.labelForField(widget)
                if label_in_layout:
                    label_in_layout.setVisible(False)

        for field_key in visible_keys_for_current_form:
            widget = self.fields.get(field_key)
            if widget:
                widget.setVisible(True)
                label_in_layout = self.form_entries.labelForField(widget)
                if label_in_layout:
                    label_in_layout.setVisible(True)

        is_warning_notice = current_form_internal_key == "warning_notice_form"
        is_perf_appraisal = current_form_internal_key == "performance_appraisal_form"
        is_exit_interview = current_form_internal_key == "exit_interview_form"
        is_leave = current_form_internal_key == "leave_form"
        # is_delivery = current_form_internal_key == "delivery_form" # Not currently used for specific logic below
        # is_expense_claim = current_form_internal_key == "expense_claim_form" # Not currently used for specific logic below
        
        show_generic_attachments = not (is_warning_notice or is_perf_appraisal or is_exit_interview)
        self.fields["generic_attachment_1"].setVisible(show_generic_attachments)
        if self.form_entries.labelForField(self.fields["generic_attachment_1"]): self.form_entries.labelForField(self.fields["generic_attachment_1"]).setVisible(show_generic_attachments)
        self.fields["generic_attachment_2"].setVisible(show_generic_attachments)
        if self.form_entries.labelForField(self.fields["generic_attachment_2"]): self.form_entries.labelForField(self.fields["generic_attachment_2"]).setVisible(show_generic_attachments)
        self.fields["generic_attachment_3"].setVisible(show_generic_attachments)
        if self.form_entries.labelForField(self.fields["generic_attachment_3"]): self.form_entries.labelForField(self.fields["generic_attachment_3"]).setVisible(show_generic_attachments)

        show_generic_notes = True
        self.fields["generic_notes"].setVisible(show_generic_notes)
        self.notes_label_widget.setVisible(show_generic_notes)

        for common_key in ["company_name", "name", "employee_id", "position", "department"]:
            self.fields[common_key].setVisible(True)
            label = self.form_entries.labelForField(self.fields[common_key])
            if label: label.setVisible(True)

        reason_visible = True
        # Construct translation key for reason label
        reason_text_key = f"reason_{current_form_internal_key}"
        reason_text = self._(reason_text_key, default=self._("reason_default")) # Use default if specific key not found
        self.reason_label_widget.setText(reason_text)
        self.fields["reason"].setVisible(reason_visible)
        self.reason_label_widget.setVisible(reason_visible)

        # Construct translation key for notes label
        # Fallback logic for notes label
        notes_text_key = f"notes_{current_form_internal_key}"
        notes_translation = self._(notes_text_key)
        if notes_translation == notes_text_key: # Key itself was returned, meaning no specific translation
            notes_translation = self._("notes_default")
        self.notes_label_widget.setText(notes_translation)
        # Visibility of notes_label_widget is already handled by show_generic_notes

        # Fallback logic for reason label
        if is_leave: self._calculate_leave_days()
        reason_translation = self._(reason_text_key) # reason_text_key was defined earlier
        if reason_translation == reason_text_key: # Key itself was returned, meaning no specific translation
            reason_translation = self._("reason_default")
        self.reason_label_widget.setText(reason_translation)
    def _get_form_context(self, form_type_internal_key):
        template_filename = self.form_template_files.get(form_type_internal_key)
        template_path = os.path.join(self.template_dir, template_filename) if template_filename else None
        if not os.path.exists(template_path):
            QMessageBox.critical(self, self._("template_not_found_title"), f"ไม่พบเทมเพลต: {template_path}")
            return None
        print("🔍 Template Path:", template_path)
        
        context = {
            "name": self.fields["name"].text().strip(),
            "company_name": self.fields["company_name"].text().strip(),
            "employee_id": self.fields["employee_id"].text().strip(),
            "department": self.fields["department"].text().strip(),
            "position": self.fields["position"].text().strip(),
            "reason": self.fields["reason"].toPlainText().strip(),
            "current_date": datetime.datetime.now().strftime("%d/%m/%Y"),
            "generic_attachment_1": self.fields["generic_attachment_1"].text().strip(),
            "generic_attachment_2": self.fields["generic_attachment_2"].text().strip(),
            "generic_attachment_3": self.fields["generic_attachment_3"].text().strip(),
            "generic_notes": self.fields["generic_notes"].toPlainText().strip(),
        }
        if form_type_internal_key == "leave_form":
            context["leave_type"] = self.fields["leave_type"].currentText()
            context["start_date"] = self.fields["start_date"].date().toString("dd/MM/yyyy")
            context["end_date"] = self.fields["end_date"].date().toString("dd/MM/yyyy")
            context["total_leave_days"] = self.fields["total_leave_days"].text().strip()
            context["assigned_person"] = self.fields["assigned_person"].text().strip()
            context["contact_phone_leave"] = self.fields["contact_phone_leave"].text().strip()
        elif form_type_internal_key == "resign_form":
            context["effective_date_resign"] = self.fields["effective_date_resign"].date().toString("dd/MM/yyyy")
        elif form_type_internal_key == "delivery_form":
            context["delivery_recipient_name"] = self.fields["delivery_recipient_name"].text().strip()
            context["delivery_recipient_department"] = self.fields["delivery_recipient_department"].text().strip()
        elif form_type_internal_key == "training_request_form":
            context["training_course_name"] = self.fields["training_course_name"].text().strip()
            context["training_start_date"] = self.fields["training_start_date"].date().toString("dd/MM/yyyy")
            context["training_end_date"] = self.fields["training_end_date"].date().toString("dd/MM/yyyy")
            context["training_organizer"] = self.fields["training_organizer"].text().strip()
            context["training_cost"] = self.fields["training_cost"].text().strip()
        elif form_type_internal_key == "emp_data_change_form":
            context["change_data_type"] = self.fields["change_data_type"].currentText()
            context["change_data_old_details"] = self.fields["change_data_old_details"].toPlainText().strip()
            context["change_data_new_details"] = self.fields["change_data_new_details"].toPlainText().strip()
            context["change_data_effective_date"] = self.fields["change_data_effective_date"].date().toString("dd/MM/yyyy")
        elif form_type_internal_key == "ot_request_form":
            context["ot_date"] = self.fields["ot_date"].date().toString("dd/MM/yyyy")
            context["ot_start_time"] = self.fields["ot_start_time"].text().strip()
            context["ot_end_time"] = self.fields["ot_end_time"].text().strip()
        elif form_type_internal_key == "expense_claim_form":
            for i in range(1, 4):
                context[f"expense_date_{i}"] = self.fields[f"expense_date_{i}"].date().toString("dd/MM/yyyy")
                context[f"expense_desc_{i}"] = self.fields[f"expense_desc_{i}"].text().strip()
                context[f"expense_amount_{i}"] = self.fields[f"expense_amount_{i}"].text().strip()
            context["expense_total_amount"] = self.fields["expense_total_amount"].text().strip()
            context["expense_payment_method"] = self.fields["expense_payment_method"].currentText()
            context["expense_account_number"] = self.fields["expense_account_number"].text().strip()
        elif form_type_internal_key == "general_request_form":
            context["general_request_details"] = self.fields["general_request_details"].toPlainText().strip()
        elif form_type_internal_key == "warning_notice_form":
            context["warning_date_of_incident"] = self.fields["warning_date_of_incident"].date().toString("dd/MM/yyyy")
            context["warning_previous_actions"] = self.fields["warning_previous_actions"].toPlainText().strip()
            context["warning_agreed_actions"] = self.fields["warning_agreed_actions"].toPlainText().strip()
        elif form_type_internal_key == "exit_interview_form":
            context["exit_interview_last_work_date"] = self.fields["exit_interview_last_work_date"].date().toString("dd/MM/yyyy")
            context["exit_interview_likes"] = self.fields["exit_interview_likes"].toPlainText().strip()
            context["exit_interview_dislikes"] = self.fields["exit_interview_dislikes"].toPlainText().strip()
            context["exit_interview_suggestions"] = self.fields["exit_interview_suggestions"].toPlainText().strip()
        elif form_type_internal_key == "performance_appraisal_form":
            context["appraisal_period_start"] = self.fields["appraisal_period_start"].date().toString("dd/MM/yyyy")
            context["appraisal_period_end"] = self.fields["appraisal_period_end"].date().toString("dd/MM/yyyy")
            context["appraisal_strengths"] = self.fields["appraisal_strengths"].toPlainText().strip()
            context["appraisal_areas_for_improvement"] = self.fields["appraisal_areas_for_improvement"].toPlainText().strip()
            context["appraisal_overall_rating"] = self.fields["appraisal_overall_rating"].currentText()
        elif form_type_internal_key == "other_cert_request_form":
            context["other_cert_type_description"] = self.fields["other_cert_type_description"].text().strip()
        elif form_type_internal_key == "travel_request_form":
            context["travel_destination"] = self.fields["travel_destination"].text().strip()
            context["travel_purpose"] = self.fields["travel_purpose"].toPlainText().strip()
            context["travel_start_date"] = self.fields["travel_start_date"].date().toString("dd/MM/yyyy")
            context["travel_end_date"] = self.fields["travel_end_date"].date().toString("dd/MM/yyyy")
            context["travel_advance_amount"] = self.fields["travel_advance_amount"].text().strip()
        elif form_type_internal_key == "purchase_request_form":
            context["purchase_item_desc"] = self.fields["purchase_item_desc"].toPlainText().strip()
            context["purchase_quantity"] = self.fields["purchase_quantity"].text().strip()
            context["purchase_supplier_suggestion"] = self.fields["purchase_supplier_suggestion"].text().strip()
        elif form_type_internal_key == "accident_report_form":
            context["accident_datetime"] = self.fields["accident_datetime"].text().strip()
            context["accident_location"] = self.fields["accident_location"].text().strip()
            context["accident_details"] = self.fields["accident_details"].toPlainText().strip()
            context["accident_witnesses"] = self.fields["accident_witnesses"].text().strip()
        return context

    def _validate_form_data(self, form_type_internal_key, context):
        required_fields_map = {
            "ชื่อบริษัท": context.get("company_name"),
            "ชื่อพนักงาน": context.get("name"),
            "รหัสพนักงาน": context.get("employee_id"),
            "ตำแหน่ง": context.get("position"),
            "แผนก/ฝ่าย": context.get("department"),
        }

        if form_type_internal_key == "leave_form":
            required_fields_map["จำนวนวันลา"] = context.get("total_leave_days")
            try:
                total_days_str = context.get("total_leave_days", "0")
                if total_days_str == "วันที่ไม่ถูกต้อง":
                     QMessageBox.warning(self, "ข้อมูลไม่ถูกต้อง", "วันที่สิ้นสุดการลาต้องไม่ก่อนวันที่เริ่มลา")
                     return False
                total_days_int = int(total_days_str)
                if total_days_int <= 0:
                    QMessageBox.warning(self, "ข้อมูลไม่ถูกต้อง", "จำนวนวันลาต้องเป็นจำนวนเต็มบวก")
                    return False
            except ValueError:
                QMessageBox.warning(self, "ข้อมูลไม่ถูกต้อง", "จำนวนวันลาต้องเป็นตัวเลข")
                return False
            start_qdate = self.fields["start_date"].date()
            end_qdate = self.fields["end_date"].date()
            if start_qdate > end_qdate:
                QMessageBox.warning(self, "ข้อมูลไม่ถูกต้อง", "วันที่สิ้นสุดการลาต้องไม่ก่อนวันที่เริ่มลา")
                return False
        elif form_type_internal_key == "resign_form":
            required_fields_map["วันที่มีผล (ลาออก)"] = context.get("effective_date_resign")
        elif form_type_internal_key == "delivery_form":
            required_fields_map["ผู้รับ (ใบส่งเอกสาร)"] = context.get("delivery_recipient_name")
            required_fields_map["เรื่อง (ใบส่งเอกสาร)"] = context.get("reason")
        elif form_type_internal_key == "training_request_form":
            required_fields_map["ชื่อหลักสูตรอบรม"] = context.get("training_course_name")
            required_fields_map["วัตถุประสงค์/ประโยชน์"] = context.get("reason")
        elif form_type_internal_key == "emp_data_change_form":
            required_fields_map["ข้อมูลใหม่"] = context.get("change_data_new_details")
        elif form_type_internal_key == "ot_request_form":
            required_fields_map["เหตุผลการขอทำโอที"] = context.get("reason")
            required_fields_map["เวลาเริ่มโอที"] = context.get("ot_start_time")
            required_fields_map["เวลาสิ้นสุดโอที"] = context.get("ot_end_time")
            # Validate OT time format and logic
            time_pattern = r"^\d{2}:\d{2}$"
            if not re.match(time_pattern, context.get("ot_start_time","")):
                QMessageBox.warning(self, "ข้อมูลไม่ถูกต้อง", "รูปแบบเวลาเริ่มโอทีไม่ถูกต้อง (HH:MM)")
                return False
            if not re.match(time_pattern, context.get("ot_end_time","")):
                QMessageBox.warning(self, "ข้อมูลไม่ถูกต้อง", "รูปแบบเวลาสิ้นสุดโอทีไม่ถูกต้อง (HH:MM)")
                return False
            # Add more logic: end_time > start_time if needed
            # try:
            #     datetime.datetime.strptime(context.get("ot_end_time"), "%H:%M") > datetime.datetime.strptime(context.get("ot_start_time"), "%H:%M")
            # except ValueError: pass # Already caught by regex
        elif form_type_internal_key == "cert_employment_form":
            required_fields_map["วัตถุประสงค์การขอใบรับรอง"] = context.get("reason")
        elif form_type_internal_key == "expense_claim_form":
            has_expense_item = False
            for i in range(1, 4):
                if context.get(f"expense_desc_{i}") and context.get(f"expense_amount_{i}"):
                    has_expense_item = True
                    try:
                        float(context.get(f"expense_amount_{i}"))
                    except ValueError:
                        QMessageBox.warning(self, "ข้อมูลไม่ถูกต้อง", f"จำนวนเงินในรายการเบิกที่ {i} ต้องเป็นตัวเลข")
                        return False
            if not has_expense_item:
                required_fields_map["รายการเบิกอย่างน้อย 1 รายการ"] = ""
        elif form_type_internal_key == "general_request_form":
            required_fields_map["เรื่องที่ร้องขอ"] = context.get("reason")
            required_fields_map["รายละเอียดคำร้อง"] = context.get("general_request_details")
        elif form_type_internal_key == "warning_notice_form":
            required_fields_map["รายละเอียดการกระทำผิด/ปัญหา"] = context.get("reason")
        elif form_type_internal_key == "other_cert_request_form":
            required_fields_map["ประเภทหนังสือรับรองที่ขอ"] = context.get("other_cert_type_description")
            required_fields_map["วัตถุประสงค์การขอ"] = context.get("reason")
        elif form_type_internal_key == "travel_request_form":
            required_fields_map["สถานที่ไปราชการ"] = context.get("travel_destination")
            required_fields_map["วัตถุประสงค์การเดินทาง"] = context.get("travel_purpose")
            required_fields_map["เหตุผลความจำเป็นในการเดินทาง"] = context.get("reason")
        elif form_type_internal_key == "purchase_request_form":
            required_fields_map["รายการ/รายละเอียด (จัดซื้อ)"] = context.get("purchase_item_desc")
            required_fields_map["จำนวน (จัดซื้อ)"] = context.get("purchase_quantity")
            required_fields_map["เหตุผลความจำเป็น (จัดซื้อ/จัดจ้าง)"] = context.get("reason")
            try:
                qty = int(context.get("purchase_quantity", "0"))
                if qty <= 0:
                    QMessageBox.warning(self, "ข้อมูลไม่ถูกต้อง", "จำนวน (จัดซื้อ) ต้องเป็นตัวเลขจำนวนเต็มบวก")
                    return False
            except ValueError:
                QMessageBox.warning(self, "ข้อมูลไม่ถูกต้อง", "จำนวน (จัดซื้อ) ต้องเป็นตัวเลข")
                return False
        elif form_type_internal_key == "accident_report_form":
            required_fields_map["วันที่/เวลาเกิดเหตุ (อุบัติเหตุ)"] = context.get("accident_datetime")
            required_fields_map["สถานที่เกิดเหตุ (อุบัติเหตุ)"] = context.get("accident_location")
            required_fields_map["ลักษณะการเกิดอุบัติเหตุ"] = context.get("accident_details")

        missing_fields = [label for label, value in required_fields_map.items() if not value]
        if missing_fields:
            QMessageBox.warning(self, "ข้อมูลไม่ครบ",
                                self._("missing_fields_message", fields=', '.join(missing_fields)))
            return False
        return True

    def generate_form(self):
        print("📌 START generate_form")
        form_type_display_name = self.form_selector.currentText()
        form_type_internal_key = self.form_selector.currentData()

        if not form_type_internal_key:
            QMessageBox.warning(self, self._("invalid_data_title"), self._("select_form_type_prompt"))
            return

        print(f"✅ Form Type (Display): {form_type_display_name}, (Internal): {form_type_internal_key}")

        context = self._get_form_context(form_type_internal_key)
        if context is None:
            return

        if not self._validate_form_data(form_type_internal_key, context):
            return

        print("✅ Context พร้อมใช้งานแล้ว")
        print(f"DEBUG: Context for rendering: {context}")
        
        template_path = os.path.join(self.template_dir, self.form_template_files[form_type_internal_key])
        try:
            doc = DocxTemplate(template_path)
        except Exception as e:
            QMessageBox.critical(self, "❌ ข้อผิดพลาดในการโหลดเทมเพลต",
                                 f"ไม่สามารถโหลดไฟล์เทมเพลตได้: {template_path}\n"
                                 f"รายละเอียด: {e}\n\nTraceback:\n{traceback.format_exc()}")
            return

        # Signature handling removed. If templates still expect a 'signature' key,
        # you might need to add context["signature"] = "" here.
        # However, it's better if templates don't refer to it if the feature is removed.

        try:
            print(f"DEBUG: context['signature'] type: {type(context.get('signature'))}, value: {context.get('signature')}")
            doc.render(context)
            print("📝 Render DOCX เรียบร้อย")
        except Exception as e:
            QMessageBox.critical(self, "❌ ข้อผิดพลาดในการสร้างเนื้อหาเอกสาร",
                                 self.get_render_error_message(e, context))
            return

        safe_name = context.get("name", "unknown").replace(" ", "_").replace("/", "_").replace("\\", "_")
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{form_type_display_name.replace(' ', '_')}_{safe_name}_{timestamp}" # Use display name for filename
        output_docx = os.path.join(self.output_dir, filename + ".docx")

        try:
            doc.save(output_docx)
        except Exception as e:
            QMessageBox.critical(self, "❌ ข้อผิดพลาดในการบันทึกไฟล์ DOCX",
                                 f"ไม่สามารถบันทึกไฟล์เอกสารได้: {output_docx}\n"
                                 f"รายละเอียด: {e}\n\nTraceback:\n{traceback.format_exc()}")
            return
        print("💾 บันทึก DOCX แล้ว:", output_docx)

        final_path = output_docx
        if DOCX2PDF_AVAILABLE:
            try:
                print("🔁 แปลง PDF ...")
                output_pdf = os.path.join(self.output_dir, filename + ".pdf")
                docx2pdf.convert(output_docx, output_pdf)
                final_path = output_pdf
                print("✅ แปลง PDF เสร็จ:", final_path)
            except Exception as e:
                print(f"❌ PDF แปลงไม่สำเร็จ: {e}")
                QMessageBox.warning(self, "⚠️ แปลง PDF ไม่สำเร็จ",
                                    f"ไม่สามารถแปลงไฟล์เป็น PDF ได้ ระบบจะใช้ไฟล์ .docx แทน\n"
                                    f"รายละเอียดข้อผิดพลาด: {e}\n\n"
                                    f"อาจเกิดจาก:\n"
                                    f"- ไม่ได้ติดตั้ง Microsoft Word (สำหรับ Windows) หรือ LibreOffice (สำหรับ Linux/macOS)\n"
                                    f"- ปัญหาอื่นๆ กับไลบรารี docx2pdf")

        db_name = context.get("name", "")
        db_position = context.get("position", "")
        # file_path_val is final_path
        db_reason = context.get("reason", "") # This is common
        db_leave_type_specific = context.get("leave_type", "") if form_type_internal_key == "leave_form" else ""
        db_start_date_specific = context.get("start_date", "") if form_type_internal_key == "leave_form" else ""
        db_end_date_specific = context.get("end_date", "") if form_type_internal_key == "leave_form" else ""
        db_employee_id = context.get("employee_id", "")
        db_department = context.get("department", "")
        db_company_name = context.get("company_name", "")
        db_total_leave_days = context.get("total_leave_days", "") if form_type_internal_key == "leave_form" else ""
        db_assigned_person = context.get("assigned_person", "") if form_type_internal_key == "leave_form" else ""
        db_contact_phone_leave = context.get("contact_phone_leave", "") if form_type_internal_key == "leave_form" else ""
        db_effective_date_resign = context.get("effective_date_resign", "") if form_type_internal_key == "resign_form" else ""
        db_delivery_recipient_name = context.get("delivery_recipient_name", "") if form_type_internal_key == "delivery_form" else ""
        db_delivery_recipient_department = context.get("delivery_recipient_department", "") if form_type_internal_key == "delivery_form" else ""
        db_generic_attachment_1 = context.get("generic_attachment_1", "")
        db_generic_attachment_2 = context.get("generic_attachment_2", "")
        db_generic_attachment_3 = context.get("generic_attachment_3", "")
        db_generic_notes = context.get("generic_notes", "")
        db_training_course_name = context.get("training_course_name", "")
        db_training_start_date = context.get("training_start_date", "")
        db_training_end_date = context.get("training_end_date", "")
        db_training_organizer = context.get("training_organizer", "")
        db_training_cost = context.get("training_cost", "")
        db_change_data_type = context.get("change_data_type", "")
        db_change_data_old_details = context.get("change_data_old_details", "")
        db_change_data_new_details = context.get("change_data_new_details", "")
        db_change_data_effective_date = context.get("change_data_effective_date", "")
        db_ot_date = context.get("ot_date", "")
        db_ot_start_time = context.get("ot_start_time", "")
        db_ot_end_time = context.get("ot_end_time", "")
        db_expense_total_amount = context.get("expense_total_amount", "")
        db_expense_payment_method = context.get("expense_payment_method", "")
        db_general_request_details = context.get("general_request_details", "")
        db_warning_date_of_incident = context.get("warning_date_of_incident", "")
        db_warning_agreed_actions = context.get("warning_agreed_actions", "")
        db_exit_interview_last_work_date = context.get("exit_interview_last_work_date", "")
        db_exit_interview_suggestions = context.get("exit_interview_suggestions", "")
        db_appraisal_overall_rating = context.get("appraisal_overall_rating", "")
        db_warning_previous_actions = context.get("warning_previous_actions", "")
        db_exit_interview_likes = context.get("exit_interview_likes", "")
        db_exit_interview_dislikes = context.get("exit_interview_dislikes", "")
        db_appraisal_period_start = context.get("appraisal_period_start", "")
        db_appraisal_period_end = context.get("appraisal_period_end", "")
        db_appraisal_strengths = context.get("appraisal_strengths", "")
        db_appraisal_areas_for_improvement = context.get("appraisal_areas_for_improvement", "")
        db_other_cert_type_description = context.get("other_cert_type_description","") # Ensure this is fetched
        db_travel_destination = context.get("travel_destination", "")
        db_travel_purpose = context.get("travel_purpose", "")
        db_travel_start_date = context.get("travel_start_date", "")
        db_travel_end_date = context.get("travel_end_date", "")
        db_travel_advance_amount = context.get("travel_advance_amount", "")
        db_purchase_item_desc = context.get("purchase_item_desc", "")
        db_purchase_quantity = context.get("purchase_quantity", "")
        db_purchase_supplier_suggestion = context.get("purchase_supplier_suggestion", "")
        db_accident_datetime = context.get("accident_datetime", "")
        db_accident_location = context.get("accident_location", "")
        db_accident_details = context.get("accident_details", "")
        db_accident_witnesses = context.get("accident_witnesses", "")
        
        self.save_to_db(
            db_name, db_position, form_type_internal_key, final_path, db_reason, 
            db_leave_type_specific, db_start_date_specific, db_end_date_specific,
            db_employee_id, db_department, db_company_name, db_total_leave_days, 
            db_assigned_person, db_contact_phone_leave, db_effective_date_resign,
            db_delivery_recipient_name, db_delivery_recipient_department,
            db_generic_attachment_1, db_generic_attachment_2, db_generic_attachment_3, db_generic_notes,
            db_training_course_name, db_training_start_date, db_training_end_date, db_training_organizer, db_training_cost,
            db_change_data_type, db_change_data_old_details, db_change_data_new_details, db_change_data_effective_date,
            db_ot_date, db_ot_start_time, db_ot_end_time,
            db_expense_total_amount, db_expense_payment_method,
            db_general_request_details,
            db_warning_date_of_incident, db_warning_agreed_actions,
            db_exit_interview_last_work_date, db_exit_interview_suggestions,
            db_appraisal_overall_rating,
            db_warning_previous_actions, db_exit_interview_likes, db_exit_interview_dislikes,
            db_appraisal_period_start, db_appraisal_period_end,
            db_appraisal_strengths, db_appraisal_areas_for_improvement,
            db_other_cert_type_description, 
            db_travel_destination, db_travel_purpose, db_travel_start_date, db_travel_end_date, db_travel_advance_amount,
            db_purchase_item_desc, db_purchase_quantity, db_purchase_supplier_suggestion,
            db_accident_datetime, db_accident_location, db_accident_details, db_accident_witnesses
        )
        self.load_history()

        QMessageBox.information(self, self._("success_title"), self._("document_created_message", path=final_path))
        try:
            print("📂 เปิดไฟล์ด้วย os.startfile()")
            if os.path.exists(final_path):
                os.startfile(final_path)
            else:
                QMessageBox.warning(self, self._("file_not_found_warning_title"), f"ไม่พบไฟล์ที่สร้าง: {final_path}")
        except Exception as e:
            QMessageBox.warning(self, self._("open_file_error_warning_title"), f"ไม่สามารถเปิดไฟล์ {final_path} โดยอัตโนมัติได้\nกรุณาเปิดไฟล์ด้วยตนเองจากโฟลเดอร์ outputs")

        print("✅ END generate_form")

    def init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            c = conn.cursor()
            # Construct CREATE TABLE statement dynamically from self.db_all_columns
            # id is INTEGER PRIMARY KEY AUTOINCREMENT, others are TEXT
            column_definitions = ["id INTEGER PRIMARY KEY AUTOINCREMENT"]
            for col_name in self.db_column_names_for_insert: # Excludes 'id'
                column_definitions.append(f"{col_name} TEXT")
            
            create_table_sql = f"CREATE TABLE IF NOT EXISTS form_history ({', '.join(column_definitions)})"
            c.execute(create_table_sql)
            
            c.execute("PRAGMA table_info(form_history)")
            current_columns_in_db = [info[1] for info in c.fetchall()]

            for col_to_add in self.db_all_columns: # self.db_all_columns includes 'id'
                if col_to_add not in current_columns_in_db:
                    if col_to_add != "id": # 'id' should already exist or be handled by PK
                        try:
                            c.execute(f"ALTER TABLE form_history ADD COLUMN {col_to_add} TEXT")
                            print(f"✅ Added column: {col_to_add}")
                        except sqlite3.Error as alter_e:
                            print(f"❌ Failed to add column {col_to_add}: {alter_e}")
            conn.commit()

    def save_to_db(self, name, position, form_type_internal_key, file_path_val, reason, leave_type_specific, start_date_specific, end_date_specific, 
                    employee_id, department, company_name, total_leave_days, assigned_person, contact_phone_leave,
                    effective_date_resign, delivery_recipient_name, delivery_recipient_department,
                    generic_attachment_1, generic_attachment_2, generic_attachment_3, generic_notes,
                    training_course_name, training_start_date, training_end_date, training_organizer, training_cost,
                    change_data_type, change_data_old_details, change_data_new_details, change_data_effective_date,
                    ot_date, ot_start_time, ot_end_time,
                    expense_total_amount, expense_payment_method,
                    general_request_details,
                    warning_date_of_incident, warning_agreed_actions,
                    exit_interview_last_work_date, exit_interview_suggestions,
                    appraisal_overall_rating,
                    warning_previous_actions, exit_interview_likes, exit_interview_dislikes,
                    appraisal_period_start, appraisal_period_end,
                    appraisal_strengths, appraisal_areas_for_improvement,
                    other_cert_type_description,
                    travel_destination, travel_purpose, travel_start_date, travel_end_date, travel_advance_amount,
                    purchase_item_desc, purchase_quantity, purchase_supplier_suggestion,
                    accident_datetime, accident_location, accident_details, accident_witnesses
                    ):
        created_at_val = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Order of values must match self.db_column_names_for_insert
        values_tuple = (
            name, position, form_type_internal_key, created_at_val, file_path_val, reason, 
            leave_type_specific, start_date_specific, end_date_specific, employee_id, department,
            company_name, total_leave_days, assigned_person, contact_phone_leave, effective_date_resign,
            delivery_recipient_name, delivery_recipient_department, generic_attachment_1,
            generic_attachment_2, generic_attachment_3, generic_notes,
            training_course_name, training_start_date, training_end_date, training_organizer, training_cost,
            change_data_type, change_data_old_details, change_data_new_details, change_data_effective_date,
            ot_date, ot_start_time, ot_end_time,
            expense_total_amount, expense_payment_method, general_request_details,
            warning_date_of_incident, warning_agreed_actions, exit_interview_last_work_date, exit_interview_suggestions,
            appraisal_overall_rating,
            warning_previous_actions, exit_interview_likes, exit_interview_dislikes,
            appraisal_period_start, appraisal_period_end, appraisal_strengths, appraisal_areas_for_improvement,
            other_cert_type_description,
            travel_destination, travel_purpose, travel_start_date, travel_end_date, travel_advance_amount,
            purchase_item_desc, purchase_quantity, purchase_supplier_suggestion,
            accident_datetime, accident_location, accident_details, accident_witnesses
        )

        if len(values_tuple) != len(self.db_column_names_for_insert):
            QMessageBox.critical(self, "DB Save Error", 
                                 f"Mismatch in values to save. Expected {len(self.db_column_names_for_insert)}, got {len(values_tuple)}.\n"
                                 f"Please contact developer. Values: {values_tuple[:5]}... Columns: {self.db_column_names_for_insert[:5]}...")
            return

        with sqlite3.connect(self.db_path) as conn:
            c = conn.cursor()
            sql = f"INSERT INTO form_history ({', '.join(self.db_column_names_for_insert)}) VALUES ({', '.join(['?'] * len(self.db_column_names_for_insert))})"
            try:
                c.execute(sql, values_tuple)
                conn.commit()
            except sqlite3.Error as e:
                QMessageBox.critical(self, "DB Save Error", f"Could not save to database: {e}\nSQL: {sql}\nValues: {values_tuple}")
                print(f"DB Save Error: {e}\nSQL: {sql}\nValues: {values_tuple}")


    def load_history(self):
        rows = []
        try:
            with sqlite3.connect(self.db_path) as conn:
                c = conn.cursor()
                select_columns_str = ", ".join(self.db_all_columns)
                c.execute(f"SELECT {select_columns_str} FROM form_history ORDER BY id DESC")
                rows = c.fetchall()

            self.table.setRowCount(len(rows))
            
            display_column_names = [
                "name", "employee_id", "department", "position", "form_type_internal_key", 
                "reason", "leave_type_specific", "start_date_specific", 
                "end_date_specific", "created_at"
            ]
            display_data_indices = [self.db_all_columns.index(col_name) for col_name in display_column_names]

            for i, row_data in enumerate(rows):
                for col_idx_in_table, data_idx in enumerate(display_data_indices):
                    val = row_data[data_idx]
                    item_value = str(val) if val is not None else ""
                    
                    # Translate form_type_internal_key for display
                    if display_column_names[col_idx_in_table] == "form_type_internal_key":
                        item_value = self._(item_value) # Translate the internal key

                    item = QTableWidgetItem(item_value)
                    self.table.setItem(i, col_idx_in_table, item)
                
                if self.table.item(i, 0):
                    record_id = row_data[self.db_all_columns.index("id")]
                    file_path_value = row_data[self.db_all_columns.index("file_path")]
                    
                    self.table.item(i, 0).setData(Qt.UserRole, record_id)
                    self.table.item(i, 0).setData(Qt.UserRole + 1, file_path_value if file_path_value is not None else "")

            self.table.resizeColumnsToContents()

        except sqlite3.Error as e:
            QMessageBox.critical(self, self._("db_error_title"), self._("db_load_history_error", e=e))
            self.table.setRowCount(0)
        except ValueError as ve: # Handles .index() not found if db_all_columns is out of sync
             QMessageBox.critical(self, self._("db_column_error_title"), self._("db_column_error_message", e=ve))
             self.table.setRowCount(0)


    def open_history_file(self, item_clicked):
        row = item_clicked.row()
        first_item_in_row = self.table.item(row, 0)
        if first_item_in_row:
            file_path = first_item_in_row.data(Qt.UserRole + 1)
            if file_path and os.path.exists(file_path): # file_path is "" if None, or actual path
                try:
                    os.startfile(file_path)
                except Exception as e:
                    QMessageBox.warning(self, self._("open_file_error_warning_title"), f"ไม่สามารถเปิดไฟล์ {file_path} โดยอัตโนมัติได้\nรายละเอียด: {e}")
            elif file_path: # file_path has a value but does not exist
                QMessageBox.warning(self, self._("file_not_found_warning_title"), self._("history_file_moved_or_deleted", path=file_path))
            else: # file_path is empty (was None)
                 QMessageBox.warning(self, self._("no_file_for_history_item_warning_title"), self._("no_file_for_history_item_message"))

    def delete_selected_history(self):
        selected_rows = self.table.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.information(self, self._("delete_history_info_title"), self._("select_item_to_delete_message"))
            return

        reply = QMessageBox.question(self, self._("confirm_delete_title"),
                                     self._("confirm_delete_message", count=len(selected_rows)),
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            ids_to_delete = []
            files_to_delete = []
            for index in selected_rows:
                row = index.row()
                item = self.table.item(row, 0)
                if item:
                    record_id = item.data(Qt.UserRole)
                    file_path = item.data(Qt.UserRole + 1) # Will be "" if None
                    ids_to_delete.append(record_id)
                    if file_path: # Only add if not an empty string
                        files_to_delete.append(file_path)
            
            try:
                with sqlite3.connect(self.db_path) as conn:
                    c = conn.cursor()
                    for record_id in ids_to_delete:
                        c.execute("DELETE FROM form_history WHERE id = ?", (record_id,))
                    conn.commit()
                
                deleted_count = 0
                for file_path_to_delete in files_to_delete:
                    if os.path.exists(file_path_to_delete):
                         try:
                            os.remove(file_path_to_delete)
                            print(f"🗑️ Deleted file: {file_path_to_delete}")
                            deleted_count += 1
                         except Exception as file_e:
                            print(f"❌ Failed to delete file {file_path_to_delete}: {file_e}")
                
                QMessageBox.information(self, self._("success_title"), self._("delete_success_message", count=len(ids_to_delete), file_count=deleted_count))
            except Exception as e:
                QMessageBox.critical(self, self._("delete_fail_title"), f"เกิดข้อผิดพลาดขณะลบข้อมูล:\n{e}")
            self.load_history()

    def _change_language(self):
        selected_lang_code = self.lang_selector.currentData()
        set_language(selected_lang_code)
        self._ = get_translator() # Update the instance's translator
        self._retranslate_ui()

    def _retranslate_ui(self):
        # Retranslate all static text elements
        self.setWindowTitle(self._("window_title"))
        
        # Main header (assuming it's the first QLabel in the main layout)
        # A more robust way would be to store a reference to this QLabel
        # For now, let's assume it's accessible or find it.
        # If self.header is defined: self.header.setText(self._("main_header"))
        # Or find it:
        if hasattr(self, 'lang_label'):
            self.lang_label.setText(self._("language_label"))
        main_layout = self.layout()
        if main_layout and main_layout.count() > 0:
            header_widget = main_layout.itemAt(0).widget()
            if isinstance(header_widget, QLabel) and header_widget.objectName() == "mainHeaderLabel":
                header_widget.setText(self._("main_header"))

        # Form selector label (if it's part of QFormLayout)
        form_selector_label = self.form_entries.labelForField(self.form_selector)
        if form_selector_label:
            form_selector_label.setText(self._("select_form_type_label"))

        # Retranslate form type options in QComboBox
        current_form_key = self.form_selector.currentData()
        self.form_selector.blockSignals(True)
        self.form_selector.clear()
        for internal_key in FORM_TYPE_INTERNAL_KEYS:
            display_name = self._(internal_key)
            self.form_selector.addItem(display_name, internal_key)
        # Restore selection
        if current_form_key:
            index = self.form_selector.findData(current_form_key)
            if index != -1:
                self.form_selector.setCurrentIndex(index)
        self.form_selector.blockSignals(False)

        # Retranslate QFormLayout labels using self.form_layout_structure
        # This includes the labels for notes and reason fields, which will be set to their "default" translation.
        # The update_fields_visibility() call later will set form-specific text for notes/reason.
        for label_key, widget_identifier in self.form_layout_structure:
            if label_key: # Only process if there's a label key (e.g., expense headers have None)
                # Determine the actual widget associated with the field part of the row
                actual_widget_for_field = self.fields.get(widget_identifier) if isinstance(widget_identifier, str) else widget_identifier
                if actual_widget_for_field:
                    label_widget = self.form_entries.labelForField(actual_widget_for_field)
                    if label_widget: # Check if a label widget exists for this field
                        label_widget.setText(self._(label_key))

        # Retranslate specific labels like reason and notes
        self.reason_label_widget.setText(self._("reason_default")) # Will be updated by update_fields_visibility
        self.notes_label_widget.setText(self._("notes_default"))   # Will be updated by update_fields_visibility

        # Retranslate buttons
        self.submit_btn.setText(self._("submit_button"))
        self.submit_btn.setToolTip(self._("tooltip_submit_button"))
        self.clear_form_btn.setText(self._("clear_button"))
        self.clear_form_btn.setToolTip(self._("tooltip_clear_button"))
        self.open_output_folder_btn.setText(self._("open_folder_button"))
        self.open_output_folder_btn.setToolTip(self._("tooltip_open_folder_button"))
        self.delete_history_btn.setText(self._("delete_history_button"))
        self.delete_history_btn.setToolTip(self._("tooltip_delete_history_button"))

        # Retranslate table headers
        self.table.setHorizontalHeaderLabels([
            self._("history_name"), self._("history_employee_id"),
            self._("history_department"), self._("history_position"),
            self._("history_form_type"), self._("history_reason_subject"),
            self._("history_leave_type"), self._("history_start_date"),
            self._("history_end_date"), self._("history_created_at")
        ])

        # Retranslate combobox items (leave_type, change_data_type, etc.)
        # This also needs a more robust approach, similar to form_selector
        def retranslate_combobox(combo_box_key, option_keys_list):
            combo_box = self.fields.get(combo_box_key)
            if combo_box:
                current_data = combo_box.currentData() # Assuming we store internal keys as data
                combo_box.blockSignals(True)
                combo_box.clear()
                for option_key in option_keys_list:
                    combo_box.addItem(self._(option_key), option_key) # Store option_key as data
                if current_data:
                    index = combo_box.findData(current_data)
                    if index != -1:
                        combo_box.setCurrentIndex(index)
                else: # If no data was stored, try to match by text (less reliable)
                    # This part is complex if currentText was used before.
                    pass
                combo_box.blockSignals(False)
        
        retranslate_combobox("leave_type", LEAVE_TYPE_OPTION_KEYS)
        retranslate_combobox("change_data_type", CHANGE_DATA_TYPE_OPTION_KEYS)
        retranslate_combobox("expense_payment_method", EXPENSE_PAYMENT_METHOD_OPTION_KEYS)
        retranslate_combobox("appraisal_overall_rating", APPRAISAL_RATING_OPTION_KEYS)

        # Update field visibility which also updates some labels
        self.update_fields_visibility()
        # Reload history to show translated form types
        self.load_history()

        # Retranslate tool tips
        self.fields["accident_datetime"].setToolTip(self._("tooltip_accident_datetime"))

        # Retranslate QLineEdit default values if needed (e.g., company_name if it's not cleared)
        # This requires direct access to translations dict, which is not ideal from main.py
        # A better check would be if the text is empty or matches the *current language's* default.
        # For simplicity, if it's empty, set it.
        if not self.fields["company_name"].text().strip():
            self.fields["company_name"].setText(self._(DEFAULT_COMPANY_NAME_KEY))

        # Retranslate expense headers
        self.fields["expense_header_1"].setText(self._("expense_header_1_text"))
        self.fields["expense_header_2"].setText(self._("expense_header_2_text"))
        self.fields["expense_header_3"].setText(self._("expense_header_3_text"))

        # Retranslate browse buttons for attachments
        # Iterate through the stored form structure to find attachment layouts
        for label_key, widget_or_identifier in self.form_layout_structure:
            if label_key and "attachment" in label_key: # Identifies attachment rows
                # widget_or_identifier for attachments is the QHBoxLayout instance itself
                if isinstance(widget_or_identifier, QHBoxLayout):
                    attachment_layout = widget_or_identifier
                    for i in range(attachment_layout.count()):
                        item_widget = attachment_layout.itemAt(i).widget()
                        if isinstance(item_widget, QPushButton):
                            item_widget.setText(self._("browse_button"))
                            break # Assuming one browse button per attachment layout

        print(f"UI Retranslated to: {get_current_language_code()}")


    def get_render_error_message(self, exception, context):
        exception_str = str(exception).lower()
        base_message = ""

        if "package not found" in exception_str:
            file_path_in_error = "ไฟล์เทมเพลตที่ระบุ"
            match = re.search(r"package not found at '([^']*)'", str(exception), re.IGNORECASE)
            if match:
                file_path_in_error = os.path.basename(match.group(1))
            base_message = (
                f"**ข้อผิดพลาดร้ายแรงกับไฟล์เทมเพลต '{file_path_in_error}':**\n"
                f"ไม่สามารถอ่านไฟล์เทมเพลตได้ เนื่องจากไฟล์อาจเสียหาย หรือไม่ใช่รูปแบบ .docx ที่ถูกต้อง\n"
                f"กรุณา:\n"
                f"1. ลองเปิดไฟล์นี้ด้วย Microsoft Word โดยตรง หากเปิดไม่ได้หรือมีข้อความแจ้งข้อผิดพลาด แสดงว่าไฟล์เสียหาย\n"
                f"2. หาก Word เปิดได้ ลอง 'Save As' (บันทึกเป็น) ไฟล์นี้ใหม่เป็น .docx อีกครั้ง\n"
                f"3. ตรวจสอบให้แน่ใจว่าเป็นไฟล์ .docx จริงๆ ไม่ใช่ไฟล์ .doc ที่เปลี่ยนชื่อนามสกุล\n\n"
            )
        elif isinstance(exception, KeyError):
             missing_key = str(exception).strip("'")
             base_message = (
                f"**ข้อผิดพลาดเกี่ยวกับ Placeholder ในเทมเพลต:**\n"
                f"ไม่พบข้อมูลสำหรับ Placeholder ชื่อ `{missing_key}` ในเทมเพลต Word ของคุณ.\n"
                f"กรุณาตรวจสอบไฟล์เทมเพลต `{self.form_template_files.get(self.form_selector.currentData(), 'ไม่ทราบชื่อไฟล์')}`\n"
                f"และแก้ไข Placeholder `{{{{ {missing_key} }}}}` ให้ถูกต้อง หรือตรวจสอบว่าคุณได้กรอกข้อมูลในช่องที่เกี่ยวข้องครบถ้วนแล้ว\n\n"
                f"Placeholder ที่โปรแกรมส่งไปคือ: {list(context.keys())}\n\n"
            )
        else:
            base_message = (
                f"เกิดปัญหาขณะเตรียมข้อมูลลงในเอกสาร:\n"
                f"- ข้อมูลที่กรอกอาจมีปัญหา\n"
                f"- Placeholder บางตัวในไฟล์เทมเพลต Word (.docx) อาจมีรูปแบบไม่ถูกต้อง\n"
            )

        return f"{base_message}รายละเอียดข้อผิดพลาด: {exception}\n\nTraceback:\n{traceback.format_exc()}"

def global_exception_handler(exc_type, exc_value, exc_traceback):
    if issubclass(exc_type, SystemExit):
        return
    error_message = "".join(traceback.format_exception(exc_type, exc_value, exc_traceback))
    full_message = (
        f"เกิดข้อผิดพลาดที่ไม่คาดคิด:\n\n"
        f"{exc_type.__name__}: {exc_value}\n\n"
        f"กรุณาแจ้งรายละเอียดนี้ให้ผู้พัฒนา:\n{error_message}"
    )
    # Check if QApplication instance exists before creating QMessageBox
    # to avoid "QWidget: Must construct a QApplication before a QWidget"
    q_app_instance = QApplication.instance()
    if q_app_instance: # type: ignore
        QMessageBox.critical(None, "💥 ข้อผิดพลาดร้ายแรง", full_message)
    else:
        # Fallback if QApplication is not yet created or already destroyed
        print("CRITICAL ERROR (QApplication not available for QMessageBox):")
        print(full_message)
        # Forcing exit might be too harsh, but good for development to see the error
        # sys.exit(1) 

if __name__ == '__main__':
    sys.excepthook = global_exception_handler
    
    app = QApplication(sys.argv)
    window = SmartFormApp()
    window.show()    
    sys.exit(app.exec_())
